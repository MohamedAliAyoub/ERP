<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuthorizeSubscription extends Model
{
    protected $table = 'authorize_subscriptions';
}
