<?php

namespace App;

class Country extends BaseModel
{
    protected $table = 'countries';
}
