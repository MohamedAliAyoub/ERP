<?php

namespace App;

class CompanySetting extends BaseModel
{
    protected $table = 'organisation_settings';
}
